package com.example.login_app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class HomeInterface extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_interface);

        //get intent
        Intent mainToHome = getIntent();

        String username = "Username : " + mainToHome.getStringExtra("username");
        String password = "Password : " + mainToHome.getStringExtra("password");

        //get textview
        final TextView usernameDisplay = findViewById(R.id.username_display);
        final TextView passwordDisplay = findViewById(R.id.password_display);

        //get back button
        final Button logoutButton = findViewById(R.id.logout_button);

        usernameDisplay.setText(username);
        passwordDisplay.setText(password);

        logoutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent backToLogin = new Intent(HomeInterface.this, MainActivity.class);

                startActivity(backToLogin);
            }
        });
    }
}