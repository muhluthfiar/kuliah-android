package com.example.login_app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // get the objects
        final Button loginbutton = (Button) findViewById(R.id.login_button);
        final EditText usernameText = (EditText) findViewById(R.id.username);
        final EditText passwordText = (EditText) findViewById(R.id.password);

        loginbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // redirect
                Intent toHome = new Intent(MainActivity.this, HomeInterface.class);
                toHome.putExtra("username", usernameText.getText().toString());
                toHome.putExtra("password", passwordText.getText().toString());

                startActivity(toHome);
            }
        });
    }
}